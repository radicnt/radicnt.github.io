// add simple cursor parallax effect
window.addEventListener("mousemove", e => {
  document.body.style.setProperty("--x", `${e.clientX}px`);
  document.body.style.setProperty("--y", `${e.clientY}px`);
});